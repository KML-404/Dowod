# Dowód sprzedaży – aplikacja na Androida

Aplikacja robi dowód sprzedaży w Twoim wzorze (numer `#ROK/NNN`, kod kreskowy `ROKNNN`, zasady, podatek) i przekazuje go kupującemu:

- **NFC (bez naklejki)**: przykładasz telefon do telefonu kupującego, a u niego otwiera się WhatsApp z gotową wiadomością do Ciebie („poproszę dowód sprzedaży nr …”). Odpisujesz mu zdjęciem.
- **Odwrócony kod QR**: to samo, ale kupujący skanuje kod aparatem.
- **WhatsApp ze zdjęciem**: wpisujesz numer kupującego, a aplikacja otwiera czat z nim i od razu dołącza zdjęcie (z Twojego numeru).
- MMS / SMS, udostępnianie, zapis do galerii, pełny ekran.
- Opcjonalnie drugi kod QR ze zdjęciem na stronie podglądu (`viewer/`).

Zasady na dowodzie: zwroty, stan techniczny, reklamacje (tylko gdy stan nie zgadza się z opisem z mojej pomyłki), brak praw konsumenta, VAT, kontakt. Każdą włączasz osobno dla profilu. Linię „Sprzedawca” też można wyłączyć.

Dwa profile (Vinted / Targi staroci) pamiętają osobno: nazwę sklepu, metodę płatności, podatek, zasady, numer kontaktowy.

## Czego NIE ma
Aplikacja nie łączy się z kontem Vinted – dane sprzedaży wpisujesz ręcznie.

---

## Wersja bez Android Studio (GitHub buduje wszystko za Ciebie)

W repozytorium jest gotowy plik `.github/workflows/build.yml`. Po wrzuceniu projektu na GitHub:

1. Konto na github.com → **New repository** (np. `dowod`, **Public**).
2. Wgraj do niego całą zawartość folderu `DowodSprzedazy` (razem z ukrytym folderem `.github`).
   Najprościej: *Add file → Upload files* i przeciągnij wszystko z folderu.
3. **Settings → Pages → Source: GitHub Actions** (jednorazowo).
4. Zakładka **Actions**: poczekaj ok. 5–10 minut, aż oba zadania będą zielone.
5. Zakładka **Releases → „najnowsza”**: pobierz `dowod-sprzedazy.apk` na telefonie i zainstaluj.
6. Adres strony podglądu to `https://TWOJA-NAZWA.github.io/dowod/` – wpisz go w aplikacji.

## Krok 1 – strona podglądu (potrzebna dla QR i NFC)

QR i NFC nie mogą przenieść zdjęcia, więc przenoszą **link**. Dane dowodu są spakowane w tym linku po znaku `#`
(ta część nigdy nie trafia na żaden serwer), a strona `viewer/index.html` sama rysuje z nich zdjęcie.
Strona nie przechowuje żadnych dowodów.

1. Załóż darmowe konto na github.com.
2. **New repository** → nazwa np. `dowod` → **Public** → Create.
3. **Add file → Upload files** → wrzuć plik `viewer/index.html` (z tego folderu) → Commit.
4. **Settings → Pages** → *Source*: `Deploy from a branch`, branch `main`, folder `/ (root)` → Save.
5. Po 1–2 minutach strona działa pod adresem `https://TWOJA-NAZWA.github.io/dowod/`.

Ten adres wpiszesz w aplikacji (pole na dole formularza).

## Krok 2 – zbudowanie aplikacji

1. Zainstaluj **Android Studio** (darmowe).
2. *Open* → wskaż folder `DowodSprzedazy`. Poczekaj, aż skończy się „Gradle sync” (pobiera biblioteki, trwa kilka minut).
3. Podłącz telefon kablem (włączone *Opcje programisty → Debugowanie USB*) i kliknij zielony ▶ **Run**,
   albo: *Build → Build APK(s)* i przenieś plik `app-debug.apk` na telefon.
4. Telefon może poprosić o zgodę na instalację aplikacji spoza Sklepu Play.

> Kod napisałem bez możliwości uruchomienia go na telefonie. Jeśli Android Studio pokaże błąd, skopiuj
> jego treść i wyślij mi – poprawię.

## Krok 3 – użycie

1. Wybierz profil, wpisz produkt, cenę, (numer i data podpowiadają się same).
2. Wpisz **adres strony podglądu** z kroku 1 (zapamięta się).
3. **Generuj dowód sprzedaży**. Pod zdjęciem pojawi się kod QR i przyciski.
4. Kupujący:
   - **QR** – skanuje aparatem swojego telefonu,
   - **NFC** – zostaw aplikację otwartą na tym ekranie i przyłóż tył swojego telefonu do tyłu jego telefonu,
   - **MMS** – wpisz jego numer w formularzu i kliknij „Wyślij MMS”. Otworzą się Wiadomości z załączonym zdjęciem; jeśli numer się nie wpisał, wpisz go ręcznie i wyślij.

## Ograniczenia, o których warto wiedzieć

- **MMS**: nie wysyła się sam – zawsze dotykasz „Wyślij” w aplikacji Wiadomości. Operator może zmniejszyć zdjęcie, a MMS bywa płatny.
  To, czy numer wpisze się automatycznie, zależy od aplikacji do wiadomości (Google Messages / Samsung zwykle tak).
- **NFC**: telefon udaje „naklejkę NFC” z linkiem. Wymaga włączonego ekranu i NFC po obu stronach.
  Telefon kupującego otwiera link; iPhone’y (XS i nowsze) zwykle też, ale nie mam tego jak sprawdzić.
  NFC nie przesyła samego zdjęcia (jest za wolne) – tylko link do strony podglądu.
- **Kod QR/NFC bez strony podglądu**: zawiera tylko tekst dowodu, bez zdjęcia.
- **Numer sprzedaży**: aplikacja pamięta ostatni numer osobno dla każdego roku. Możesz go zmienić ręcznie.
- **Podatek 0%** = na dowodzie „Podatek: zwolniony z VAT”.
- Treść zasad to Twój wzór, nie porada prawna. Zwolnienie z VAT (art. 113) wpisuj tylko, jeśli faktycznie z niego korzystasz.
