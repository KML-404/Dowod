package pl.dowod.sprzedazy

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Telefon udaje etykietę NFC (NFC Forum Type 4 Tag) z jednym rekordem NDEF = adres URL.
 * Drugi telefon, przyłożony do tego, otwiera ten adres w przeglądarce.
 * Działa przy włączonym ekranie; najpewniej, gdy aplikacja jest otwarta na pierwszym planie.
 */
class NfcTagService : HostApduService() {

    private var selectedFile = 0 // 0 nic, 1 CC (E103), 2 NDEF (E104)

    override fun processCommandApdu(apdu: ByteArray, extras: Bundle?): ByteArray {
        if (apdu.size < 4) return SW_UNKNOWN
        val ins = apdu[1].toInt() and 0xFF
        val p1 = apdu[2].toInt() and 0xFF
        val p2 = apdu[3].toInt() and 0xFF

        when (ins) {
            0xA4 -> { // SELECT
                if (p1 == 0x04) { // wybór aplikacji po nazwie (AID)
                    selectedFile = 0
                    val len = if (apdu.size > 4) apdu[4].toInt() and 0xFF else 0
                    if (apdu.size >= 5 + len && apdu.copyOfRange(5, 5 + len).contentEquals(AID)) return SW_OK
                    return SW_NOT_FOUND
                }
                if (p1 == 0x00) { // wybór pliku po ID
                    if (apdu.size >= 7) {
                        val id = ((apdu[5].toInt() and 0xFF) shl 8) or (apdu[6].toInt() and 0xFF)
                        if (id == 0xE103) { selectedFile = 1; return SW_OK }
                        if (id == 0xE104 && ndefFile != null) { selectedFile = 2; return SW_OK }
                    }
                    return SW_NOT_FOUND
                }
                return SW_NOT_FOUND
            }
            0xB0 -> { // READ BINARY
                val data = when (selectedFile) {
                    1 -> capabilityContainer()
                    2 -> ndefFile
                    else -> null
                } ?: return SW_NOT_FOUND
                val offset = ((p1 and 0x7F) shl 8) or p2
                var le = if (apdu.size > 4) apdu[4].toInt() and 0xFF else 0
                if (le == 0) le = 256
                if (offset > data.size) return SW_WRONG_PARAMS
                val end = minOf(data.size, offset + le)
                return data.copyOfRange(offset, end) + SW_OK
            }
        }
        return SW_UNKNOWN
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = 0
    }

    private fun capabilityContainer(): ByteArray {
        val max = MAX_NDEF_SIZE
        return byteArrayOf(
            0x00, 0x0F,             // długość CC
            0x20,                   // wersja mapowania 2.0
            0x00, 0x3B,             // MLe: maks. odczyt
            0x00, 0x34,             // MLc: maks. zapis
            0x04, 0x06,             // TLV: NDEF File Control
            0xE1.toByte(), 0x04,    // ID pliku NDEF
            ((max shr 8) and 0xFF).toByte(), (max and 0xFF).toByte(),
            0x00,                   // odczyt dozwolony
            0xFF.toByte(),          // zapis zabroniony
        )
    }

    companion object {
        private val AID = byteArrayOf(
            0xD2.toByte(), 0x76, 0x00, 0x00, 0x85.toByte(), 0x01, 0x01,
        )
        private val SW_OK = byteArrayOf(0x90.toByte(), 0x00)
        private val SW_NOT_FOUND = byteArrayOf(0x6A, 0x82.toByte())
        private val SW_WRONG_PARAMS = byteArrayOf(0x6B, 0x00)
        private val SW_UNKNOWN = byteArrayOf(0x6D, 0x00)

        const val MAX_NDEF_SIZE = 2048

        @Volatile
        var ndefFile: ByteArray? = null
            private set

        /** Ustawia adres, który zostanie przesłany przez NFC. Zwraca false, gdy jest za długi. */
        fun setUrl(url: String?): Boolean {
            if (url.isNullOrBlank()) {
                ndefFile = null
                return true
            }
            val file = buildNdefFile(url)
            if (file.size > MAX_NDEF_SIZE) return false
            ndefFile = file
            return true
        }

        fun buildNdefFile(url: String): ByteArray {
            val prefixes = listOf(
                "https://www." to 0x02, "http://www." to 0x01,
                "https://" to 0x04, "http://" to 0x03,
            )
            var code = 0x00
            var rest = url
            for ((p, c) in prefixes) {
                if (url.startsWith(p)) { code = c; rest = url.substring(p.length); break }
            }
            val payload = byteArrayOf(code.toByte()) + rest.toByteArray(Charsets.UTF_8)
            val short = payload.size < 256
            val header: Byte = if (short) 0xD1.toByte() else 0xC1.toByte()
            val record = if (short) {
                byteArrayOf(header, 0x01, payload.size.toByte(), 0x55) + payload
            } else {
                byteArrayOf(
                    header, 0x01,
                    ((payload.size shr 24) and 0xFF).toByte(), ((payload.size shr 16) and 0xFF).toByte(),
                    ((payload.size shr 8) and 0xFF).toByte(), (payload.size and 0xFF).toByte(),
                    0x55,
                ) + payload
            }
            val nlen = byteArrayOf(((record.size shr 8) and 0xFF).toByte(), (record.size and 0xFF).toByte())
            return nlen + record
        }
    }
}
