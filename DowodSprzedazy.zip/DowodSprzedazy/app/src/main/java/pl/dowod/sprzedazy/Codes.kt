package pl.dowod.sprzedazy

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.oned.Code128Writer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object Codes {

    /** Moduły kodu kreskowego Code 128 (true = czarny pasek), bez marginesów. */
    fun code128Modules(text: String): BooleanArray {
        val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 0)
        val m = Code128Writer().encode(text, BarcodeFormat.CODE_128, 0, 1, hints)
        return BooleanArray(m.width) { x -> m.get(x, 0) }
    }

    /** Kod kreskowy jako długości kolejnych pasków i przerw (zaczyna od paska), np. "211412...". */
    fun code128Runs(text: String): String {
        val m = code128Modules(text)
        val sb = StringBuilder()
        var i = 0
        while (i < m.size) {
            var j = i
            while (j < m.size && m[j] == m[i]) j++
            sb.append(j - i)
            i = j
        }
        return sb.toString()
    }

    /** Kod QR jako bitmapa; rzuca wyjątek, jeśli tekst jest za długi. */
    fun qr(text: String, size: Int): Bitmap {
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 2,
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val pixels = IntArray(m.width * m.height)
        for (y in 0 until m.height) {
            for (x in 0 until m.width) {
                pixels[y * m.width + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        return Bitmap.createBitmap(pixels, m.width, m.height, Bitmap.Config.ARGB_8888)
    }
}
