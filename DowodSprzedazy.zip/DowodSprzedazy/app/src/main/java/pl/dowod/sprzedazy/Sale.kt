package pl.dowod.sprzedazy

import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.Deflater

/**
 * Jedna sprzedaż. Wszystkie kwoty są już sformatowane jako tekst (np. "59.99"),
 * żeby aplikacja i strona podglądu pokazywały dokładnie to samo.
 */
data class Sale(
    val shop: String,
    val year: Int,
    val number: Int,
    val dateText: String,
    val seller: String,
    /** czy pokazać linię „Sprzedawca” */
    val sellerOn: Boolean,
    val name: String,
    val price: String,
    val sub: String,
    val tax: String,
    val total: String,
    val rate: String,
    val pay: String,
    val tel: String,
    /** "yes" = zwrot do X dni, "no" = brak zwrotu, "none" = nie pokazuj sekcji */
    val status: String,
    val days: Int,
    /** "Vinted" albo "Targi staroci" */
    val profile: String,
    /** 6 znaków 0/1 – które zasady są włączone (zwroty, stan, reklamacje, brak praw konsumenta, VAT, kontakt) */
    val rulesFlags: String,
) {
    /** Odwrócony link: kupujący skanuje/przykłada telefon i otwiera mu się czat WhatsApp Z TOBĄ. */
    fun requestLink(): String? {
        val link = waLink(tel, "Dzień dobry, poproszę dowód sprzedaży nr $year/$numberText ($name).")
        return link.ifEmpty { null }
    }

    val numberText: String get() = String.format(Locale.US, "%03d", number)
    val code: String get() = "$year$numberText"
    val taxExempt: Boolean get() = rate == "0"

    fun rulesList(): List<String> {
        val typ = if (profile == "Vinted") "Sprzedaż prywatna" else "Sprzedaż stacjonarna"
        val zwrot = if (status == "yes" && days > 0) " Ewentualny zwrot możliwy tylko do $days dni od zakupu." else ""
        val all = listOf(
            "Zwroty: $typ. Brak możliwości zwrotu towaru bez podania przyczyny (brak ustawowego prawa do namysłu).$zwrot Prosimy o przemyślane zakupy.",
            "Stan techniczny: Kupujący zapoznał się ze stanem technicznym i wizualnym przedmiotu w momencie zakupu.",
            "Reklamacje: Nie przyjmuję zwrotu z powodu zmiany decyzji kupującego. Reklamację przyjmuję wyłącznie wtedy, gdy stan przedmiotu nie zgadza się z opisem z mojej pomyłki. Warunkiem przyjęcia reklamacji jest okazanie niniejszego dowodu sprzedaży.",
            "Sprzedaż przez osobę prywatną, nie firmę – nie obowiązują przepisy o prawach konsumenta.",
            "Podatek: Sprzedawca zwolniony z VAT na podstawie art. 113 ust. 1 i 9 ustawy o VAT.",
            "W razie problemów prosimy o kontakt: " + (if (tel.isBlank()) "(brak numeru)" else tel),
        )
        return all.filterIndexed { i, _ -> rulesFlags.getOrNull(i) == '1' }
    }

    fun returnHeadline(): String =
        if (status == "none") ""
        else if (status == "yes") "ZWROT MOŻLIWY TYLKO DO " + (if (days > 0) days else 7) + " DNI"
        else "BRAK MOŻLIWOŚCI ZWROTU"

    /** Cały dowód jako zwykły tekst (SMS, kod QR bez strony podglądu). */
    fun plainText(): String {
        val sb = StringBuilder()
        sb.append(shop.uppercase()).append('\n')
        sb.append("Dowód sprzedaży nr: #").append(year).append('/').append(numberText).append('\n')
        sb.append("Data: ").append(dateText)
        if (sellerOn && seller.isNotBlank()) sb.append("\nSprzedawca: ").append(seller)
        sb.append("\n\n")
        sb.append(name).append('\n')
        sb.append("1 x PLN ").append(price).append('\n')
        sb.append("Suma częściowa: PLN ").append(sub).append('\n')
        sb.append(if (taxExempt) "Podatek: zwolniony z VAT" else "Podatek ($rate%): PLN $tax").append('\n')
        sb.append("RAZEM: PLN ").append(total).append('\n')
        sb.append("Metoda płatności: ").append(pay)
        val rl = rulesList()
        if (status != "none" || rl.isNotEmpty()) {
            sb.append("\n")
            if (status != "none") sb.append("\n").append(returnHeadline())
            for (r in rl) sb.append("\n• ").append(r)
        }
        return sb.toString()
    }

    /** Klucze są takie same jak w viewer/index.html. */
    fun toJson(): JSONObject = JSONObject().apply {
        put("sh", shop); put("y", year); put("n", number); put("ds", dateText)
        put("ca", seller); put("so", sellerOn); put("nm", name); put("p", price); put("sb", sub)
        put("tx", tax); put("tt", total); put("pf", profile); put("dn", days)
        put("rs", rate); put("pay", pay); put("tel", tel); put("st", status)
        put("rb", rulesFlags); put("rl", org.json.JSONArray(rulesList())); put("bc", Codes.code128Runs(code))
    }

    /**
     * Link do strony podglądu: dane są spakowane (raw deflate + base64url) w części po '#',
     * która nigdy nie trafia na serwer.
     */
    fun viewerLink(base: String): String {
        val raw = toJson().toString().toByteArray(Charsets.UTF_8)
        val deflater = Deflater(Deflater.BEST_COMPRESSION, true)
        deflater.setInput(raw)
        deflater.finish()
        val out = ByteArrayOutputStream()
        val buf = ByteArray(1024)
        while (!deflater.finished()) {
            val n = deflater.deflate(buf)
            out.write(buf, 0, n)
        }
        deflater.end()
        val b64 = Base64.encodeToString(
            out.toByteArray(),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
        )
        val clean = base.trim().substringBefore('#')
        return "$clean#d=$b64"
    }

    companion object {
        /** Numer 9-cyfrowy dostaje prefiks 48. Zwraca pusty tekst, gdy numeru brak. */
        fun waLink(tel: String, text: String?): String {
            var n = tel.replace(Regex("[^0-9]"), "")
            if (n.startsWith("00")) n = n.substring(2)
            if (n.length == 9) n = "48$n"
            if (n.isEmpty()) return ""
            return "https://wa.me/$n" + if (text.isNullOrEmpty()) "" else "?text=" + java.net.URLEncoder.encode(text, "UTF-8").replace("+", "%20")
        }

        fun waDigits(tel: String): String {
            var n = tel.replace(Regex("[^0-9]"), "")
            if (n.startsWith("00")) n = n.substring(2)
            if (n.length == 9) n = "48$n"
            return n
        }
    }
}
