package pl.dowod.sprzedazy

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface

/** Rysuje dowód sprzedaży (1200 px szerokości) w układzie z wzoru. */
class ReceiptRenderer(
    private val regular: Typeface,
    private val bold: Typeface,
    private val italic: Typeface,
) {
    private val left = 60f
    private val right = 1140f

    fun render(s: Sale): Bitmap {
        
        val measure = Paint().apply { typeface = regular; textSize = 30f }
        val lines = ArrayList<String>()
        for (r in s.rulesList()) {
            wrap("• $r", measure, 1040f).forEachIndexed { i, l -> lines.add(if (i == 0) l else "  $l") }
        }
        val head = s.status != "none"
        val showPolicy = head || lines.isNotEmpty()
        val height = if (showPolicy) (if (head) 1930 else 1870) + lines.size * 44 else 1790

        val bmp = Bitmap.createBitmap(1200, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        fun text(
            t: String, x: Float, y: Float, size: Float = 38f,
            b: Boolean = false, i: Boolean = false, ls: Float = 3f,
            align: Paint.Align = Paint.Align.LEFT,
        ) {
            paint.style = Paint.Style.FILL
            paint.pathEffect = null
            paint.color = 0xFF111111.toInt()
            paint.typeface = if (b) bold else if (i) italic else regular
            paint.textSize = size
            paint.letterSpacing = ls / size
            paint.textAlign = align
            c.drawText(t, x, y, paint)
        }

        fun dash(y: Float) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = 0xFF333333.toInt()
            paint.pathEffect = DashPathEffect(floatArrayOf(9f, 6f), 0f)
            c.drawLine(left, y, right, y, paint)
        }

        fun solid(y: Float) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = 0xFF333333.toInt()
            paint.pathEffect = null
            c.drawLine(left, y, right, y, paint)
        }

        val r = Paint.Align.RIGHT
        val ctr = Paint.Align.CENTER

        text(s.shop.uppercase(), 600f, 110f, size = 58f, b = true, ls = 2f, align = ctr)
        dash(178f)
        text("Dowód sprzedaży nr:", left, 268f)
        text("#${s.year}/${s.numberText}", right, 268f, align = r)
        text("Data:", left, 346f)
        text(s.dateText, right, 346f, align = r)
        if (s.sellerOn) {
            text("Sprzedawca:", left, 424f)
            if (s.seller.isNotBlank()) text(s.seller, right, 424f, align = r)
        }
        dash(490f)

        text(s.name, left, 580f, b = true)
        text("1 x PLN ${s.price}", left, 658f)
        text("PLN ${s.price}", right, 658f, align = r)
        dash(722f)

        text("Suma częściowa:", left, 815f)
        text("PLN ${s.sub}", right, 815f, align = r)
        if (s.taxExempt) {
            text("Podatek:", left, 892f)
            text("zwolniony z VAT", right, 892f, align = r)
        } else {
            text("Podatek (${s.rate}%):", left, 892f)
            text("PLN ${s.tax}", right, 892f, align = r)
        }
        solid(937f)
        text("Razem:", left, 1010f, size = 42f, b = true)
        text("PLN ${s.total}", right, 1010f, size = 42f, b = true, align = r)
        dash(1080f)

        text("Metoda płatności:", left, 1170f)
        text(s.pay, right, 1170f, align = r)
        dash(1237f)

        // kod kreskowy: rok + numer sprzedaży w roku, np. 2026001
        val modules = Codes.code128Modules(s.code)
        val scale = 4f
        val bx = (1200f - modules.size * scale) / 2f
        paint.style = Paint.Style.FILL
        paint.pathEffect = null
        paint.color = Color.BLACK
        var i = 0
        while (i < modules.size) {
            if (modules[i]) {
                var j = i
                while (j < modules.size && modules[j]) j++
                c.drawRect(bx + i * scale, 1315f, bx + j * scale, 1465f, paint)
                i = j
            } else {
                i++
            }
        }
        paint.typeface = Typeface.SANS_SERIF
        paint.textSize = 36f
        paint.letterSpacing = 1f / 36f
        paint.textAlign = Paint.Align.CENTER
        c.drawText(s.code, 600f, 1505f, paint)

        text("Dziękujemy za zakup!", 600f, 1615f, size = 32f, i = true, align = ctr)
        text("Zapraszamy ponownie", 600f, 1678f, size = 32f, i = true, align = ctr)
        text("Dowód sprzedaży – dokument nie jest paragonem fiskalnym.", 600f, 1738f, size = 24f, ls = 0f, align = ctr)

        if (showPolicy) {
            dash(1775f)
            if (head) text(s.returnHeadline(), left, 1845f, size = 36f, b = true, ls = 1f)
            val y0 = if (head) 1905f else 1845f
            lines.forEachIndexed { idx, l -> text(l, left, y0 + idx * 44f, size = 30f, ls = 0f) }
        }
        return bmp
    }

    private fun wrap(text: String, p: Paint, maxW: Float): List<String> {
        val out = ArrayList<String>()
        var line = ""
        for (w in text.split(" ")) {
            val t = if (line.isEmpty()) w else "$line $w"
            if (p.measureText(t) > maxW && line.isNotEmpty()) {
                out.add(line)
                line = w
            } else {
                line = t
            }
        }
        out.add(line)
        return out
    }
}
