package pl.dowod.sprzedazy

import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.cardemulation.CardEmulation
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private val profiles = listOf("Vinted", "Targi staroci")
    private val statusItems = listOf(
        "Zwrot możliwy tylko do określonej liczby dni",
        "Brak możliwości zwrotu",
        "Nie pokazuj sekcji zwrotu",
    )
    private val statusKeys = listOf("yes", "no", "none")
    private val ruleTitles = listOf(
        "Zwroty – brak zwrotu bez przyczyny (ewentualnie do X dni)",
        "Stan techniczny – kupujący zapoznał się ze stanem",
        "Reklamacje – tylko gdy stan nie zgadza się z opisem (moja pomyłka)",
        "Brak praw konsumenta (sprzedaż prywatna)",
        "Podatek – zwolnienie z VAT (art. 113 ust. 1 i 9)",
        "Kontakt w razie problemów",
    )
    private val ruleDefaults = listOf(true, true, true, false, true, true)

    private lateinit var prefs: SharedPreferences
    private lateinit var renderer: ReceiptRenderer
    private lateinit var root: LinearLayout
    private lateinit var resultBox: LinearLayout
    private lateinit var scroll: ScrollView

    private lateinit var spProfile: Spinner
    private lateinit var etShop: EditText
    private lateinit var etName: EditText
    private lateinit var etPrice: EditText
    private lateinit var etNum: EditText
    private lateinit var tvNumHint: TextView
    private lateinit var etTax: EditText
    private lateinit var cbIncl: CheckBox
    private lateinit var btnDate: Button
    private lateinit var btnTime: Button
    private lateinit var etSeller: EditText
    private lateinit var cbSellerOn: CheckBox
    private lateinit var etPay: EditText
    private lateinit var spStatus: Spinner
    private lateinit var etDays: EditText
    private lateinit var etTel: EditText
    private lateinit var cbRules: List<CheckBox>
    private lateinit var etBuyer: EditText
    private lateinit var etViewer: EditText

    private val cal: Calendar = Calendar.getInstance()
    private var currentProfile: String? = null
    private var numDirty = false
    private var settingNum = false

    private var lastSale: Sale? = null
    private var lastBitmap: Bitmap? = null

    // ---------------------------------------------------------------- UI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("dowod", MODE_PRIVATE)
        renderer = ReceiptRenderer(
            resources.getFont(R.font.lm_regular),
            resources.getFont(R.font.lm_bold),
            resources.getFont(R.font.lm_italic),
        )

        scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Generator dowodów sprzedaży"
            textSize = 22f
            setTextColor(Color.BLACK)
        })

        label("Profil sprzedaży")
        spProfile = spinner(profiles)

        label("Nazwa sklepu")
        etShop = edit("DEMON GAMING STORE")
        label("Nazwa produktu")
        etName = edit("np. Playstation 3 Slim")
        label("Cena (PLN)")
        etPrice = edit("59.99", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)

        label("Nr sprzedaży w roku")
        etNum = edit("1", InputType.TYPE_CLASS_NUMBER)
        tvNumHint = TextView(this).apply { textSize = 12f }
        root.addView(tvNumHint)
        etNum.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { if (!settingNum) numDirty = true }
        })

        label("Podatek (%) – 0 = zwolniony z VAT")
        etTax = edit("0", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        cbIncl = CheckBox(this).apply { text = "Wpisana cena zawiera podatek" }
        root.addView(cbIncl)

        label("Data i godzina sprzedaży")
        val dateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnDate = Button(this).apply { isAllCaps = false; setOnClickListener { pickDate() } }
        btnTime = Button(this).apply { isAllCaps = false; setOnClickListener { pickTime() } }
        dateRow.addView(btnDate, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        dateRow.addView(btnTime, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(dateRow)
        refreshDateButtons()

        label("Imię i nazwisko sprzedawcy")
        etSeller = edit("np. Jan Kowalski")
        cbSellerOn = CheckBox(this).apply { text = "Pokazuj linię „Sprzedawca” na dowodzie" }
        root.addView(cbSellerOn)
        label("Metoda płatności")
        etPay = edit("Vinted")

        label("Zwrot")
        spStatus = spinner(statusItems)
        label("Dni na zwrot")
        etDays = edit("7", InputType.TYPE_CLASS_NUMBER)
        label("Twój numer kontaktowy")
        etTel = edit("np. 600 123 456", InputType.TYPE_CLASS_PHONE)

        label("Zasady na dowodzie (włącz / wyłącz)")
        cbRules = ruleTitles.map { t ->
            CheckBox(this).apply { text = t; isChecked = true }.also { root.addView(it) }
        }

        label("Numer telefonu kupującego (WhatsApp / MMS / SMS)")
        etBuyer = edit("np. 500 123 456", InputType.TYPE_CLASS_PHONE)

        label("Adres strony podglądu (opcjonalnie – drugi kod QR ze zdjęciem)")
        etViewer = edit("https://twoja-nazwa.github.io/dowod/", InputType.TYPE_TEXT_VARIATION_URI)
        etViewer.setText(prefs.getString("viewerUrl", ""))

        root.addView(Button(this).apply {
            text = "Generuj dowód sprzedaży"
            isAllCaps = false
            setOnClickListener { generate() }
        }, lpTop(20))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultBox, lpTop(16))

        spProfile.setSelection(profiles.indexOf(prefs.getString("lastProfile", "Vinted")).coerceAtLeast(0))
        spProfile.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentProfile?.let { if (it != profiles[pos]) saveProfile(it) }
                currentProfile = profiles[pos]
                loadProfile(profiles[pos])
                prefs.edit().putString("lastProfile", profiles[pos]).apply()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        suggestNumber()
    }

    override fun onResume() {
        super.onResume()
        try {
            NfcAdapter.getDefaultAdapter(this)?.let {
                CardEmulation.getInstance(it).setPreferredService(this, ComponentName(this, NfcTagService::class.java))
            }
        } catch (_: Exception) {
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            NfcAdapter.getDefaultAdapter(this)?.let {
                CardEmulation.getInstance(it).unsetPreferredService(this)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------ UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lpTop(dpv: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
    ).apply { topMargin = dp(dpv) }

    private fun label(t: String) {
        root.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setPadding(0, dp(14), 0, dp(2))
        })
    }

    private fun edit(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setSingleLine()
        root.addView(e)
        return e
    }

    private fun spinner(items: List<String>): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        root.addView(s)
        return s
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------- profiles

    private fun saveProfile(p: String) {
        prefs.edit().apply {
            putString("p.$p.shop", etShop.text.toString())
            putString("p.$p.pay", etPay.text.toString())
            putString("p.$p.tel", etTel.text.toString())
            putString("p.$p.seller", etSeller.text.toString())
            putBoolean("p.$p.sellerOn", cbSellerOn.isChecked)
            putString("p.$p.tax", etTax.text.toString())
            putString("p.$p.days", etDays.text.toString())
            putString("p.$p.status", spStatus.selectedItemPosition.toString())
            putBoolean("p.$p.incl", cbIncl.isChecked)
            cbRules.forEachIndexed { i, cb -> putBoolean("p.$p.q$i", cb.isChecked) }
            putString("viewerUrl", etViewer.text.toString().trim())
        }.apply()
    }

    private fun loadProfile(p: String) {
        fun g(k: String, d: String) = prefs.getString("p.$p.$k", d) ?: d
        etShop.setText(g("shop", "DEMON GAMING STORE"))
        etPay.setText(g("pay", if (p == "Vinted") "Vinted" else "Gotówka"))
        etTel.setText(g("tel", ""))
        etSeller.setText(g("seller", ""))
        cbSellerOn.isChecked = prefs.getBoolean("p.$p.sellerOn", false)
        etTax.setText(g("tax", "0"))
        etDays.setText(g("days", "7"))
        spStatus.setSelection((g("status", "0").toIntOrNull() ?: 0).coerceIn(0, 2))
        cbIncl.isChecked = prefs.getBoolean("p.$p.incl", false)
        cbRules.forEachIndexed { i, cb -> cb.isChecked = prefs.getBoolean("p.$p.q$i", ruleDefaults[i]) }
    }

    // ------------------------------------------------- date and number

    private fun refreshDateButtons() {
        btnDate.text = String.format(
            Locale.US, "%d.%d.%d",
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR),
        )
        btnTime.text = String.format(
            Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
        )
    }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d ->
            cal.set(y, m, d)
            refreshDateButtons()
            if (!numDirty) suggestNumber()
            updateNumHint()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun pickTime() {
        TimePickerDialog(this, { _, h, min ->
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, min)
            refreshDateButtons()
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }

    private fun lastNumber(year: Int) = prefs.getInt("last.$year", 0)

    private fun suggestNumber() {
        settingNum = true
        etNum.setText((lastNumber(cal.get(Calendar.YEAR)) + 1).toString())
        settingNum = false
        numDirty = false
        updateNumHint()
    }

    private fun updateNumHint() {
        val y = cal.get(Calendar.YEAR)
        val l = lastNumber(y)
        tvNumHint.text = if (l == 0) "Brak zapisanych sprzedaży w $y."
        else "Ostatnio wystawiony w $y: " + String.format(Locale.US, "%03d", l)
    }

    // ------------------------------------------------------- building

    private fun money(v: BigDecimal): String = v.setScale(2, RoundingMode.HALF_UP).toPlainString()

    private fun parseDecimal(s: String): BigDecimal? =
        try { BigDecimal(s.trim().replace(',', '.')) } catch (_: Exception) { null }

    private fun buildSale(): Sale? {
        val price = parseDecimal(etPrice.text.toString())
        if (price == null) { toast("Wpisz cenę, np. 59.99"); return null }
        val rate = parseDecimal(etTax.text.toString().ifBlank { "0" })
        if (rate == null) { toast("Podatek: wpisz liczbę, np. 0 albo 23"); return null }

        val hundred = BigDecimal(100)
        var sub = price
        var tax = price.multiply(rate).divide(hundred, 10, RoundingMode.HALF_UP)
        var total = price.add(tax)
        if (cbIncl.isChecked) {
            sub = price.divide(BigDecimal.ONE.add(rate.divide(hundred, 10, RoundingMode.HALF_UP)), 10, RoundingMode.HALF_UP)
            tax = price.subtract(sub)
            total = price
        }
        val year = cal.get(Calendar.YEAR)
        val dateText = String.format(
            Locale.US, "%d.%d.%d, %02d:%02d:%02d",
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, year,
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND),
        )
        var number = etNum.text.toString().trim().toIntOrNull() ?: 0
        if (number <= 0) number = lastNumber(year) + 1

        return Sale(
            shop = etShop.text.toString().ifBlank { "SKLEP" },
            year = year,
            number = number,
            dateText = dateText,
            seller = etSeller.text.toString().trim(),
            sellerOn = cbSellerOn.isChecked,
            name = etName.text.toString().trim().ifBlank { "Produkt" },
            price = money(price),
            sub = money(sub),
            tax = money(tax),
            total = money(total),
            rate = if (rate.signum() == 0) "0" else rate.stripTrailingZeros().toPlainString(),
            pay = etPay.text.toString(),
            tel = etTel.text.toString().trim(),
            status = statusKeys[spStatus.selectedItemPosition],
            days = etDays.text.toString().trim().toIntOrNull() ?: 0,
            profile = profiles[spProfile.selectedItemPosition],
            rulesFlags = cbRules.joinToString("") { if (it.isChecked) "1" else "0" },
        )
    }

    private fun generate() {
        val sale = buildSale() ?: return
        saveProfile(sale.profile)
        prefs.edit().putInt("last.${sale.year}", maxOf(sale.number, lastNumber(sale.year))).apply()
        updateNumHint()
        showResult(sale)
    }

    // ---------------------------------------------------------- result

    private fun viewerBase(): String = etViewer.text.toString().trim()

    private fun showResult(sale: Sale) {
        val bmp = renderer.render(sale)
        lastSale = sale
        lastBitmap = bmp
        resultBox.removeAllViews()

        resultBox.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setBackgroundColor(Color.WHITE)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // KOD QR (odwrócony): kupujący skanuje -> w jego WhatsAppie otwiera się wiadomość do Ciebie
        val req = sale.requestLink()
        val base = viewerBase()
        val viewer = if (base.startsWith("http")) sale.viewerLink(base) else null
        if (req != null) {
            addQr(req, "Kod QR: kupujący skanuje go aparatem, otwiera mu się WhatsApp z gotową wiadomością do Ciebie („poproszę dowód sprzedaży…”). Odpisz mu zdjęciem – przycisk „Zapisz / Udostępnij” poniżej.")
        } else {
            addQr(viewer ?: sale.plainText(),
                if (viewer != null) "Kod QR: pokazuje zdjęcie dowodu w przeglądarce. Wpisz swój numer kontaktowy, żeby kod otwierał czat WhatsApp z Tobą."
                else "Kod QR zawiera tekst dowodu. Wpisz swój numer kontaktowy, a kod otworzy kupującemu czat WhatsApp z Tobą.")
        }
        if (req != null && viewer != null) {
            addQr(viewer, "Drugi kod QR: pokazuje samo zdjęcie dowodu w przeglądarce.")
        }

        // NFC: telefon udaje „naklejkę” z tym samym linkiem co kod QR
        val nfcLink = req ?: viewer
        if (nfcLink != null) {
            val ok = NfcTagService.setUrl(nfcLink)
            val adapter = NfcAdapter.getDefaultAdapter(this)
            resultBox.addView(note(
                when {
                    !ok -> "NFC: link jest za długi, użyj kodu QR."
                    adapter == null -> "NFC: ten telefon nie ma NFC."
                    !adapter.isEnabled -> "NFC jest wyłączone w telefonie. Włącz je w ustawieniach."
                    req != null -> "NFC aktywne: trzymaj tę aplikację otwartą na tym ekranie i przyłóż tył telefonu do telefonu kupującego – otworzy mu się WhatsApp z wiadomością do Ciebie."
                    else -> "NFC aktywne: przyłożenie telefonu kupującemu otworzy zdjęcie dowodu."
                }
            ))
            if (adapter != null && !adapter.isEnabled) {
                resultBox.addView(button("Otwórz ustawienia NFC") {
                    try { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) } catch (_: Exception) {}
                })
            }
        } else {
            NfcTagService.setUrl(null)
            resultBox.addView(note("NFC działa po wpisaniu Twojego numeru kontaktowego (profil) albo adresu strony podglądu."))
        }

        resultBox.addView(button("Wyślij zdjęcie na WhatsApp kupującego") { sendWhatsApp() })
        resultBox.addView(button("Wyślij MMS ze zdjęciem na numer kupującego") { sendMms() })
        resultBox.addView(button("Wyślij SMS z tekstem dowodu") { sendSms() })
        resultBox.addView(button("Udostępnij zdjęcie (inne aplikacje)") { shareImage() })
        resultBox.addView(button("Zapisz w galerii (PNG)") { saveToGallery() })
        resultBox.addView(button("Pokaż na pełnym ekranie") { showFullscreen() })
        resultBox.addView(button("Nowa sprzedaż") { newSale() })

        scroll.post { scroll.smoothScrollTo(0, resultBox.top) }
    }

    private fun addQr(text: String, caption: String) {
        val qr = try { Codes.qr(text, 720) } catch (e: Exception) { null }
        if (qr != null) {
            resultBox.addView(ImageView(this).apply { setImageBitmap(qr) },
                LinearLayout.LayoutParams(dp(300), dp(300)).apply { topMargin = dp(16); gravity = android.view.Gravity.CENTER_HORIZONTAL })
            resultBox.addView(note(caption))
        } else {
            resultBox.addView(note("Nie udało się zrobić kodu QR (za dużo danych)."))
        }
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = lpTop(8)
    }

    private fun newSale() {
        val now = Calendar.getInstance()
        cal.timeInMillis = now.timeInMillis
        refreshDateButtons()
        etName.setText("")
        etPrice.setText("")
        etBuyer.setText("")
        suggestNumber()
        resultBox.removeAllViews()
        NfcTagService.setUrl(null)
        scroll.smoothScrollTo(0, 0)
    }

    // --------------------------------------------------------- sending

    private fun buyerNumber(): String? {
        var n = etBuyer.text.toString().replace(Regex("[^0-9+]"), "")
        if (n.isEmpty()) { toast("Wpisz numer telefonu kupującego w formularzu"); return null }
        if (Regex("^[0-9]{9}$").matches(n)) n = "+48$n"
        return n
    }

    /** Zapisuje zmniejszoną wersję JPG (MMS ma limity rozmiaru) i zwraca adres przez FileProvider. */
    private fun jpegUri(maxWidth: Int, quality: Int): Uri? {
        val sale = lastSale ?: return null
        val src = lastBitmap ?: return null
        val bmp = if (src.width > maxWidth) {
            Bitmap.createScaledBitmap(src, maxWidth, src.height * maxWidth / src.width, true)
        } else src
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        val f = File(dir, "dowod-sprzedazy-${sale.year}-${sale.numberText}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
    }

    private fun sendMms() {
        val number = buyerNumber() ?: return
        val sale = lastSale ?: return
        val uri = jpegUri(900, 80) ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra("address", number)
            putExtra("sms_body", "Dowód sprzedaży nr ${sale.year}/${sale.numberText}")
            putExtra(Intent.EXTRA_TEXT, "Dowód sprzedaży nr ${sale.year}/${sale.numberText}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val smsPkg = Telephony.Sms.getDefaultSmsPackage(this)
        try {
            if (smsPkg != null) intent.setPackage(smsPkg)
            startActivity(intent)
            toast("Jeśli numer się nie wpisał, wpisz go ręcznie: $number")
        } catch (e: ActivityNotFoundException) {
            intent.setPackage(null)
            try {
                startActivity(Intent.createChooser(intent, "Wyślij zdjęcie"))
            } catch (e2: ActivityNotFoundException) {
                toast("Nie znaleziono aplikacji do wysłania zdjęcia")
            }
        }
    }

    /** WhatsApp: otwiera czat z kupującym od razu ze zdjęciem (numer z formularza). */
    private fun sendWhatsApp() {
        val number = buyerNumber() ?: return
        val sale = lastSale ?: return
        val uri = jpegUri(1200, 90) ?: return
        val digits = Sale.waDigits(number)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Dowód sprzedaży nr ${sale.year}/${sale.numberText}")
            putExtra("jid", "$digits@s.whatsapp.net")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                intent.setPackage(pkg)
                startActivity(intent)
                toast("Jeśli czat się nie wybrał, wybierz kontakt: $number")
                return
            } catch (_: ActivityNotFoundException) {
            }
        }
        toast("Nie znaleziono WhatsAppa na tym telefonie")
    }

    private fun sendSms() {
        val number = buyerNumber() ?: return
        val sale = lastSale ?: return
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
            putExtra("sms_body", sale.plainText())
        }
        try { startActivity(intent) } catch (e: ActivityNotFoundException) { toast("Brak aplikacji SMS") }
    }

    private fun shareImage() {
        val uri = jpegUri(1200, 90) ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Udostępnij dowód sprzedaży"))
    }

    private fun saveToGallery() {
        val sale = lastSale ?: return
        val bmp = lastBitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "dowod-sprzedazy-${sale.year}-${sale.numberText}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DowodySprzedazy")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Nie udało się zapisać"); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        toast("Zapisano w galerii (Pictures/DowodySprzedazy)")
    }

    private fun showFullscreen() {
        val bmp = lastBitmap ?: return
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val sv = ScrollView(this).apply { setBackgroundColor(Color.WHITE) }
        sv.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setOnClickListener { d.dismiss() }
        }, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(sv)
        d.show()
    }
}
